using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StaticValue : MonoBehaviour
{
    public static int Level = SceneManager.GetActiveScene().buildIndex;
    public static bool load = false;
    public static int file = 0;
    public static int ZombieNumber;
    public static int ZombieHistory;
    public static int ZombieTotal;
    public static int ZombieKilled;
    public static bool Pass = false;
    public static bool Finalboss = false;
    public static PlayerData playerdata;
}
