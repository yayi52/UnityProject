using System.Collections;
using System.Collections.Generic;
using Timers;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CreateZombies : MonoBehaviour
{
    [SerializeField] private GameObject ZombiePrefab;
    [SerializeField] private float height;
    [SerializeField] private int max;
    [SerializeField] private Transform player;
    // Start is called before the first frame update

    void Start()
    {
        StaticValue.ZombieNumber = 0;
        StaticValue.ZombieHistory = 0;
        StaticValue.ZombieTotal = max;
        CreateZombie();
    }
    // Update is called once per frame
    void Update()
    {
        
    }
    private void CreateZombie()
    {
        if(StaticValue.ZombieHistory<max && StaticValue.ZombieNumber<10)
        {
            StaticValue.ZombieHistory++;
            StaticValue.ZombieNumber++;
            switch(SceneManager.GetActiveScene().buildIndex)
            {
                case 1:
                    if(Random.value<0.5f)
                    {
                        Instantiate(ZombiePrefab, new Vector2(-20,height), Quaternion.identity);
                    }
                    else 
                    {
                        Instantiate(ZombiePrefab, new Vector2(20,height), Quaternion.identity);
                    }
                    break;
                case 2:
                    Instantiate(ZombiePrefab, new Vector2(player.position.x+20,height), Quaternion.identity);
                    break;
                case 3:
                    Instantiate(ZombiePrefab, new Vector2(player.position.x+20,height), Quaternion.identity);
                    break;
                default: break;
            }       
            TimersManager.SetTimer(this,1,CreateZombie);     
        }
        else TimersManager.SetTimer(this,1,CreateZombie);
    }
}