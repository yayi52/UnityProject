using System.Collections;
using System.Collections.Generic;
using Timers;
using UnityEngine;

public class CreateZombies : MonoBehaviour
{
    [SerializeField] private GameObject ZombiePrefab;
    [SerializeField] private float height;
    // Start is called before the first frame update

    void Start()
    {
        StaticValue.ZombieNumber = 0;
        StaticValue.ZombieHistory = 0;
        CreateZombie();
    }
    // Update is called once per frame
    void Update()
    {
        
    }
    private void CreateZombie()
    {
        if(StaticValue.ZombieHistory<20 && StaticValue.ZombieNumber<10)
        {
            StaticValue.ZombieHistory++;
            StaticValue.ZombieNumber++;
            if(Random.value<0.5f)
            {
                Instantiate(ZombiePrefab, new Vector2(-20,height), Quaternion.identity);
            }
            else 
            {
                Instantiate(ZombiePrefab, new Vector2(20,height), Quaternion.identity);
            }       
            TimersManager.SetTimer(this,1,CreateZombie);     
        }
        else return;
    }
}