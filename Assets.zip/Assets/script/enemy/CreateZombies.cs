using System.Collections;
using System.Collections.Generic;
using Timers;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CreateZombies : MonoBehaviour
{
    [SerializeField] private GameObject ZombiePrefab;
    [SerializeField] private float height;
    [SerializeField] private int max;
    [SerializeField] private Transform player;
    [SerializeField] private BoxCollider2D Camerabounding3;
    private int count= 0;

    void Start()
    {
        StaticValue.ZombieNumber = 0;
        StaticValue.ZombieHistory = 0;
        if(SceneManager.GetActiveScene().buildIndex==1) 
        {
            StaticValue.ZombieKilled = 0;
            StaticValue.health = 0;
        }
        if(StaticValue.hard==false)
        {
            StaticValue.ZombieTotal = max;
            if(!StaticValue.load)StaticValue.ZombieRemain = max;
            else 
            {
                StaticValue.ZombieHistory = StaticValue.ZombieTotal - StaticValue.ZombieRemain;
                StaticValue.ZombieKilled = StaticValue.ZombieTotal - StaticValue.ZombieRemain;
            }
        }
        else 
        {
            StaticValue.ZombieTotal = max+5;
            if(!StaticValue.load)StaticValue.ZombieRemain = max+5;
        }
        CreateZombie();
    }
    // Update is called once per frame
    void Update()
    {

    }
    private void CreateZombie()
    {
        if(!StaticValue.Finalboss)
        {
            if(StaticValue.ZombieHistory<StaticValue.ZombieTotal && StaticValue.ZombieNumber<10)
            {
                StaticValue.ZombieHistory++;
                StaticValue.ZombieNumber++;
                Create();
            }
            else TimersManager.SetTimer(this,1,CreateZombie);
        }
        else Finalwave();
    }
    private void Create()
    {
        switch(SceneManager.GetActiveScene().buildIndex)//判斷第幾關
        {
            //第一關，從角色左右隨機生成
            case 1:
                if(Random.value<0.5f)
                {
                    Instantiate(ZombiePrefab, new Vector2(-20,height), Quaternion.identity);
                }
                else 
                {
                    Instantiate(ZombiePrefab, new Vector2(20,height), Quaternion.identity);
                }
                break;
            //第二關，從角色右側生成
            case 2:
                Instantiate(ZombiePrefab, new Vector2(player.position.x+20,height), Quaternion.identity);
                break;
            //第三關，一般情況，從角色右側生成
            case 3:  
                Instantiate(ZombiePrefab, new Vector2(player.position.x+20,height), Quaternion.identity);
                break;
            default: break;
        }
        TimersManager.SetTimer(this,1,CreateZombie);
    }
    //第三關，最終生存
    private void Finalwave()
    {
        count++;
        Debug.Log("FinalWave activate!:zombie created:" + count);
        Instantiate(ZombiePrefab, new Vector2(Camerabounding3.offset.x-Camerabounding3.size.x/2-Random.Range(1,10),
                    height), Quaternion.identity);
        TimersManager.SetTimer(this,1,Finalwave);    
    }
}