using System.Collections;
using System.Collections.Generic;
using Timers;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CreateZombies : MonoBehaviour
{
    [SerializeField] private GameObject ZombiePrefab;
    [SerializeField] private float height;
    [SerializeField] private int max;
    [SerializeField] private Transform player;
    [SerializeField] private BoxCollider2D Camerabounding3;
    // Start is called before the first frame update

    void Start()
    {
        StaticValue.ZombieNumber = 0;
        StaticValue.ZombieHistory = 0;
        StaticValue.ZombieTotal = max;
        CreateZombie();
    }
    // Update is called once per frame
    void Update()
    {
        
    }
    private void CreateZombie()
    {
        if(StaticValue.ZombieHistory<max && StaticValue.ZombieNumber<10)
        {
            StaticValue.ZombieHistory++;
            StaticValue.ZombieNumber++;
            switch(SceneManager.GetActiveScene().buildIndex)
            {
                case 1:
                    if(Random.value<0.5f)
                    {
                        Instantiate(ZombiePrefab, new Vector2(-20,height), Quaternion.identity);
                    }
                    else 
                    {
                        Instantiate(ZombiePrefab, new Vector2(20,height), Quaternion.identity);
                    }
                    break;
                case 2:
                    Instantiate(ZombiePrefab, new Vector2(player.position.x+20,height), Quaternion.identity);
                    break;
                case 3:
                    if(StaticValue.Finalboss)
                    {   
                        finalwave();
                    }
                    else
                    {
                        Instantiate(ZombiePrefab, new Vector2(player.position.x+20,height), Quaternion.identity);
                    }
                    break;
                default: break;
            }       
            TimersManager.SetTimer(this,1,CreateZombie);     
        }
        else TimersManager.SetTimer(this,1,CreateZombie);
    }
    private void finalwave()
    {
        if(!StaticValue.Pass)
        {
            Instantiate(ZombiePrefab, new Vector2(Camerabounding3.offset.x-Camerabounding3.size.x/2-Random.Range(1,10),
                        height), Quaternion.identity);
            TimersManager.SetTimer(this,1,finalwave);
        }
    }
}