using UnityEditor.Experimental.GraphView;
using UnityEngine;

public class enemymove : MonoBehaviour
{
    [SerializeField] private Transform playertransform;
    public float speed = 2.0f;
    private Vector2 direction;
    public int damage = 1;
    private bool isCollidingWithPlayer = false; 
    public SpriteRenderer spriteRenderer;
    private Animator m_animator;//要換到attack那邊

    void Start()
    {
        m_animator=GetComponent<Animator>();
    }
    void Update()
    {
        if(playermanager.position == (Vector2)transform.position) return;
        else
        {
            //m_animator.SetBool("attack", false); 
            direction = (Vector2)playermanager.position - (Vector2)transform.position;
            direction.Normalize();
            var directionx = new Vector2(direction.x , 0);
            if(directionx.x > 0) spriteRenderer.flipX = false;
            if(directionx.x < 0) spriteRenderer.flipX = true;
            // ���ʩǪ�
            transform.Translate(directionx * speed * Time.deltaTime);
            Debug.Log("Zombie Ramaining :"+StaticValue.ZombieNumber +"\nZombie Created :" + StaticValue.ZombieHistory);
        }
    }
}
