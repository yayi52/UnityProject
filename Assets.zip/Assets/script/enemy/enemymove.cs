using UnityEngine;

public class enemymove : MonoBehaviour
{
    [SerializeField] private Transform playertransform;
    public float speed = 2.0f;
    private Vector2 direction;
    public int damage = 1;
    private bool isCollidingWithPlayer = false; 
    void Update()
    {
        if(playermanager.position == (Vector2)transform.position) return;
        direction = (Vector2)playermanager.position - (Vector2)transform.position;
        direction.Normalize();
        var directionx = new Vector2(direction.x , 0);
        // ���ʩǪ�
        transform.Translate(directionx * speed * Time.deltaTime);
        Debug.Log("Zombie Ramaining :"+StaticValue.ZombieNumber +"\nZombie Created :" + StaticValue.ZombieHistory);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            isCollidingWithPlayer = true;
            Damageable player = collision.gameObject.GetComponent<Damageable>();
            if (player != null)
            {
                player.TakeDamage(damage);
            }
        }
        else
        {
            //direction = Vector2.Reflect(direction, collision.contacts[0].normal);
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (isCollidingWithPlayer && collision.gameObject.CompareTag("Player"))
        {
            Damageable player = collision.gameObject.GetComponent<Damageable>();
            if (player != null)
            {
                player.TakeDamage(damage);
            }
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            isCollidingWithPlayer = false;
        }
    }
}
