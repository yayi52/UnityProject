using UnityEngine;

public class enemymove : MonoBehaviour
{
    public float speed = 2.0f;
    private Vector2 direction;
    public int damage = 1;
    private bool isCollidingWithPlayer = false; 

    void Start()
    {
        // �H���M�w�q�����٬O�k��X�{
        if (Random.value > 0.5f)
        {
            // �q����X�{�A�V�k����
            transform.position = new Vector2(-10, Random.Range(-5f, 5f));  // �]�m�@�ӱq����X�{����m
            direction = Vector2.right;
        }
        else
        {
            // �q�k��X�{�A�V������
            transform.position = new Vector2(10, Random.Range(-5f, 5f));  // �]�m�@�ӱq�k��X�{����m
            direction = Vector2.left;
        }
    }

    void Update()
    {
        // ���ʩǪ�
        transform.Translate(direction * speed * Time.deltaTime);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            isCollidingWithPlayer = true;
            Damageable player = collision.gameObject.GetComponent<Damageable>();
            if (player != null)
            {
                player.TakeDamage(damage);
            }
        }
        else
        {
            direction = Vector2.Reflect(direction, collision.contacts[0].normal);
        }
    }

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (isCollidingWithPlayer && collision.gameObject.CompareTag("Player"))
        {
            Damageable player = collision.gameObject.GetComponent<Damageable>();
            if (player != null)
            {
                player.TakeDamage(damage);
            }
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            isCollidingWithPlayer = false;
        }
    }
}
