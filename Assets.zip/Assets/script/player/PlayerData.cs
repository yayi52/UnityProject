using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

[System.Serializable]
public class PlayerData
{
    public int Level;
    public int health;
    public bool hard;
    public float[] position;
    public float remaingTime;
    public int ammohandgun,ammoshotgun,ammoshotguntotal,ammomachinegun,ammomachineguntotal;
    public int zombieRemaining;
    public PlayerData(Health _health, playermanager _player, TimeCount _remaningTime ,test _ammo)
    {
        Level = SceneManager.GetActiveScene().buildIndex;
        hard = StaticValue.hard;
        zombieRemaining = StaticValue.ZombieRemain;
        health = _health.Value;
        remaingTime = _remaningTime.Value;
        ammohandgun = _ammo.HandGun();
        ammoshotgun = _ammo.ShotGun();
        ammoshotguntotal = _ammo.ShotGunTotal();
        ammomachinegun = _ammo.MachineGun();
        ammomachineguntotal = _ammo.MachineGunTotal();
        
        
        position = new float[2];
        position[0] = playermanager.position.x;
        position[1] = playermanager.position.y;
    }
}
