using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerData
{
    public int level;
    public int health;
    public float[] position;
    public float remaingTime;
    public int ammohandgun,ammoshotgun,ammoshotguntotal,ammomachinegun,ammomachineguntotal;
    public PlayerData(Health _health, playermanager _player, TimeCount _remaningTime ,test _ammo)
    {
        level = 1;
        health = _health.Value;
        remaingTime = _remaningTime.Value;
        ammohandgun = _ammo.HandGun();
        ammoshotgun = _ammo.ShotGun();
        ammoshotguntotal = _ammo.ShotGunTotal();
        ammomachinegun = _ammo.MachineGun();
        ammomachineguntotal = _ammo.MachineGunTotal();

        position = new float[2];
        position[0] = _player.position.x;
        position[1] = _player.position.y;
    }
}
