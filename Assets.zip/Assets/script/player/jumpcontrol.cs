using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpControl : MonoBehaviour
{
    private Rigidbody2D rb;

    public float jumpforce;
    public Transform groundcheck;
    public LayerMask Ground;
    public Animator m_animator;

    public bool isGround;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        m_animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        isGround = Physics2D.OverlapCircle(groundcheck.position, 0.1f, Ground);
        if (Input.GetKey(KeyCode.Space) && isGround)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpforce);
            m_animator.Play("playerjump");
        }
    }
}