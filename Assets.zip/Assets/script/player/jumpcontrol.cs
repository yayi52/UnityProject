using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpControl : MonoBehaviour
{
    [SerializeField] private test test;
    private Rigidbody2D rb;

    public float jumpforce;
    public Transform groundcheck;
    public LayerMask Ground;
    public Animator m_animator;
    public AudioSource jump;
    public bool isGround;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        m_animator = GetComponent<Animator>();
    }
    void Update()
    {
        //判斷是否人物在地面，0.1單位的誤差
        isGround = Physics2D.OverlapCircle(groundcheck.position, 0.1f, Ground);
        if (Input.GetKey(KeyCode.Space) && isGround)
        {
            jump.Play();
            rb.velocity = new Vector2(rb.velocity.x, jumpforce);
            //跳躍動畫撥放↓
            if(test.a == 1) m_animator.Play("playerjump");
            if(test.a == 2) m_animator.Play("playerjump_shotgun");
            if(test.a == 3) m_animator.Play("playerjump_machinegun");
        }
    }
}