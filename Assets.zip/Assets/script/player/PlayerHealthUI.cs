using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Rendering.Universal;
using UnityEngine.UI;

public class PlayerHealthUI : MonoBehaviour
{
    [SerializeField]private Slider healthBar;
    [SerializeField]private Health health;
    [SerializeField]private TextMeshProUGUI healthPercentage;
    private float h;
    private void Awake()
    {
        healthBar.maxValue = health.Value ;
        healthBar.value = health.Value;
    }

    // Update is called once per frame
    private void Update()
    {
        h=(healthBar.value/healthBar.maxValue)*100;
        Debug.Log("blood :"+h);
        healthPercentage.text= h.ToString() + "%";
        if(healthBar.value != health.Value)
        {
            healthBar.value = health.Value;
        }
    }
    public void UpdateUI()
    {
        healthBar.value = health.Value;
        h=(healthBar.value/healthBar.maxValue)*100;
        Debug.Log("blood :"+h);
        healthPercentage.text= h.ToString() + "%";
    }
}

