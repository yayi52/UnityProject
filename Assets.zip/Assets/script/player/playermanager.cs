using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Timers;
using UnityEditorInternal;
using UnityEngine;
//using UnityEngine.SceneManagement;


public class playermanager : MonoBehaviour
{
    private bool SaveAndLoad;
    private static playermanager _instance;
    [SerializeField] private Transform playertransform;
    [SerializeField] private TimeManager time;
    
    public static Vector2 position 
    { 
        get {return _instance.playertransform.position;}
    }
    private void Awake()
    {
        _instance = this;
    }
    private void Start()
    {
        if(StaticValue.load == true)
        {
            LoadPlayer(StaticValue.file);
        }
        TimersManager.SetTimer(this,0.5f,time.Stop);
    }
    public void setPostion(Vector2 position)
    {
        playertransform.position = position;
    }
    [SerializeField] private Health _health;
    [SerializeField] private TimeCount _remaningTime;
    [SerializeField] private test _ammo;
    
    public void SavePlayer(int file)
    {
        SaveSystem.SavePlayer(_health, this, _remaningTime, _ammo, file);
    }
    public void LoadPlayer(int file)
    {
        PlayerData data = SaveSystem.LoadPlayer(file);
        //SceneManager.LoadScene(data.level);
        _health.SetHealth(data.health);
        _remaningTime.SetRemaningTime(data.remaingTime);
        _ammo.SetHandGun(data.ammohandgun);
        _ammo.SetShotGun(data.ammoshotgun);
        _ammo.SetShotGunTotal(data.ammoshotguntotal);
        _ammo.SetMachineGun(data.ammomachinegun);
        _ammo.SetMachineGunTotal(data.ammomachineguntotal);
        StaticValue.hard = data.hard;

        Vector2 pos;
        pos.x = data.position[0];
        pos.y = data.position[1];
        this.setPostion(pos);
        StaticValue.load = false;
    }
}
