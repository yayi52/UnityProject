using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playermanager : MonoBehaviour
{
    [SerializeField] private Transform playertransform;

    public Vector2 position 
    { 
        get {return playertransform.position;}
    }

}
