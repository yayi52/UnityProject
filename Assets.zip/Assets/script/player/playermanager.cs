using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEngine.SceneManagement;


public class playermanager : MonoBehaviour
{
    private bool SaveAndLoad;
    [SerializeField] private Transform playertransform;
    public Vector2 position 
    { 
        get {return playertransform.position;}
    }
    void Awake()
    {
        LoadPlayer();
    }
    public void setPostion(Vector2 position)
    {
            playertransform.position = position;
    }
    [SerializeField] private Health _health;
    [SerializeField] private TimeCount _remaningTime;
    [SerializeField] private test _ammo;
    public void ClickLoad()
    {
        SaveAndLoad = true;
    }
    public void SavePlayer()
    {
        SaveSystem.SavePlayer(_health, this, _remaningTime, _ammo);
    }
    public void LoadPlayer()
    {
        if(SaveAndLoad)
        {
            PlayerData data = SaveSystem.LoadPlayer();
            //SceneManager.LoadScene(data.level);
            _health.SetHealth(data.health);
            _remaningTime.SetRemaningTime(data.remaingTime);
            _ammo.SetHandGun(data.ammohandgun);
            _ammo.SetShotGun(data.ammoshotgun);
            _ammo.SetShotGunTotal(data.ammoshotguntotal);
            _ammo.SetMachineGun(data.ammomachinegun);
            _ammo.SetMachineGunTotal(data.ammomachineguntotal);

            Vector2 pos;
            pos.x = data.position[0];
            pos.y = data.position[1];
            this.setPostion(pos);
            SaveAndLoad = false;
        }
    }
}
