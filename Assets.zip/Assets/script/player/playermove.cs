using UnityEngine;
using UnityEngine.InputSystem;
using DG.Tweening;
public class playermove : MonoBehaviour
{
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed;
    private Vector2 _inputdirection;

    public void Move(InputAction.CallbackContext context)
    {
        _inputdirection = context.ReadValue<Vector2>();
    }

    private void FixedUpdate()
    {
        var borderx1 = new Vector2(-15, 0);
        var borderx2 = new Vector2(15, 0);
        var bordery1 = new Vector2(0, -5);
        var bordery2 = new Vector2(0, 10);
        var positionNow = (Vector2)transform.position;
        var positionafter = positionNow + _inputdirection;

        if (positionNow == positionafter) return;
        if (positionafter.x < borderx1.x) return;
        if (positionafter.x > borderx2.x) return;
        //if (positionafter.y < bordery1.y) return;
        //if (positionafter.y < bordery2.y) return;
        rb.DOMove(positionafter , speed).SetSpeedBased();
    }

}
