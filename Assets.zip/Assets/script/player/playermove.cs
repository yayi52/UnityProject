using UnityEngine;
using UnityEngine.InputSystem;
using DG.Tweening;
using UnityEngine.Events;
using Timers;
using UnityEngine.SceneManagement;
public class playermove : MonoBehaviour
{
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed;
    [SerializeField] private TimeManager time;
    [SerializeField] private UnityEvent ESC;
    [SerializeField] private BoxCollider2D platform, platform3;
    [SerializeField] private TimeCount remainingtime;
    public SpriteRenderer spriteRenderer;
    private Vector2 _inputdirection;
    private Animator m_animator;

    void Start()
    {
        m_animator=GetComponent<Animator>();
    }

    public void Move(InputAction.CallbackContext context)
    {
        _inputdirection = context.ReadValue<Vector2>();
        if(_inputdirection.x > 0) spriteRenderer.flipX = false;
        if(_inputdirection.x < 0) spriteRenderer.flipX = true;
    }
    private void FixedUpdate()
    {
        var offset = new Vector2();
        var size = new Vector2();
        if(!StaticValue.Finalboss)
        {
            offset = platform.offset;
            size = platform.size;
        }
        else if(StaticValue.Finalboss)
        {
            offset = platform3.offset;
            size = platform3.size;
        }
        var positionNow = (Vector2)transform.position;
        var positionafter = positionNow + _inputdirection;
        if(Input.GetKey(KeyCode.D))  
        {
            m_animator.SetBool("walk", true);
            if (positionafter.x > offset.x + size.x/2-1) return;
            else rb.velocity = new Vector2(speed, rb.velocity.y);
        }
        if(Input.GetKey(KeyCode.A))  
        {
            m_animator.SetBool("walk", true);
            if (positionafter.x < offset.x - size.x/2+1) return;
            else rb.velocity = new Vector2(-speed, rb.velocity.y);
        }
        if(Input.GetKeyUp(KeyCode.D) || Input.GetKeyUp(KeyCode.A)) 
        {
            m_animator.SetBool("walk", false);
            rb.velocity = new Vector2(0,0);
        }
        if(rb.velocity == new Vector2(0,0)) m_animator.SetBool("walk", false);
        if(rb.velocity != new Vector2(0,0)) m_animator.SetBool("walk", true);
        float speedx = Mathf.Abs(rb.velocity.x);
    }
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            time.Stop();
            ESC.Invoke();
        }
        if(transform.position.x > platform.offset.x+platform.size.x/2-2 && 
           StaticValue.ZombieNumber==0 && 
           StaticValue.ZombieHistory== StaticValue.ZombieTotal &&
           SceneManager.GetActiveScene().buildIndex!= 3)
        {
            StaticValue.Pass = true;
        }
        else if (SceneManager.GetActiveScene().buildIndex == 3 && StaticValue.Finalboss)
        {
            if(remainingtime.Value<=0)
            {
                StaticValue.Pass = true;
            }
        }
    }
}
