using UnityEngine;
using UnityEngine.InputSystem;
using DG.Tweening;
using UnityEngine.Events;
using Timers;
public class playermove : MonoBehaviour
{
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed;
    [SerializeField] private TimeManager time;
    [SerializeField] private UnityEvent ESC;
    public SpriteRenderer spriteRenderer;
    private Vector2 _inputdirection;
    private Animator m_animator;

    void Start()
    {
        m_animator=GetComponent<Animator>();
    }

    public void Move(InputAction.CallbackContext context)
    {
        _inputdirection = context.ReadValue<Vector2>();
        if(_inputdirection.x > 0) spriteRenderer.flipX = false;
        if(_inputdirection.x < 0) spriteRenderer.flipX = true;
    }

    private void FixedUpdate()
    {
        var borderx1 = new Vector2(-15, 0);
        var borderx2 = new Vector2(15, 0);
        //var borderz1 = new Vector3(0, 0, -5);
        //var borderz2 = new Vector3(0, 0, 5);
        var positionNow = (Vector2)transform.position;
        var positionafter = positionNow + _inputdirection;
        if(Input.GetKey(KeyCode.D))  
        {
            m_animator.SetBool("walk", true);
            if (positionNow.x > borderx2.x) return;
            else rb.velocity = new Vector2(speed, rb.velocity.y);
        }
        if(Input.GetKey(KeyCode.A))  
        {
            m_animator.SetBool("walk", true);
            if (positionNow.x < borderx1.x) return;
            else rb.velocity = new Vector2(-speed, rb.velocity.y);
        }
        /*if(Input.GetKey(KeyCode.W))  
        {
            m_animator.SetBool("walk", true);
            if (positionNow.z > borderz2.z) return;
            else rb.velocity = new Vector3(rb.velocity.x, rb.velocity.y, speed);
        }
        if(Input.GetKey(KeyCode.S))  
        {
            m_animator.SetBool("walk", true);
            if (positionNow.z < borderz1.z) return;
            else rb.velocity = new Vector3(rb.velocity.x, rb.velocity.y, -speed);
        }*/
        if(Input.GetKeyUp(KeyCode.D) || Input.GetKeyUp(KeyCode.A)) 
        {
            m_animator.SetBool("walk", false);
            rb.velocity = new Vector2(0,0);
        }
        if(rb.velocity == new Vector2(0,0)) m_animator.SetBool("walk", false);
        if(rb.velocity != new Vector2(0,0)) m_animator.SetBool("walk", true);
        //if (positionNow == positionafter) return;
        //if (positionafter.y < bordery1.y) return;
        //if (positionafter.y < bordery2.y) return;
        //rb.DOMove(positionafter , speed).SetSpeedBased();
        float speedx = Mathf.Abs(rb.velocity.x);
    }
    private void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
        {
            time.Stop();
            ESC.Invoke();
        }
    }
}
