using UnityEngine;
using UnityEngine.InputSystem;
using DG.Tweening;
public class playermove : MonoBehaviour
{
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed;
    public SpriteRenderer spriteRenderer;
    private Vector2 _inputdirection;
    private Animator m_animator;

    void Start()
    {
        m_animator=GetComponent<Animator>();
    }

    public void Move(InputAction.CallbackContext context)
    {
        _inputdirection = context.ReadValue<Vector2>();
        if(_inputdirection.x > 0) spriteRenderer.flipX = false;
        if(_inputdirection.x < 0) spriteRenderer.flipX = true;
    }

    private void FixedUpdate()
    {
        var borderx1 = new Vector2(-15, 0);
        var borderx2 = new Vector2(15, 0);
        //var bordery1 = new Vector2(0, -5);
        //var bordery2 = new Vector2(0, 10);
        if(Input.GetKey(KeyCode.D))  rb.velocity = new Vector2(speed,0);

        if(Input.GetKey(KeyCode.A))  rb.velocity = new Vector2(-speed,0);

        if(Input.GetKeyUp(KeyCode.D) || Input.GetKeyUp(KeyCode.A)) rb.velocity = new Vector2(0,0);
        var positionNow = (Vector2)transform.position;
        var positionafter = positionNow + _inputdirection;

        //if (positionNow == positionafter) return;
        if (positionNow.x < borderx1.x) return;
        if (positionNow.x > borderx2.x) return;
        //if (positionafter.y < bordery1.y) return;
        //if (positionafter.y < bordery2.y) return;
        //rb.DOMove(positionafter , speed).SetSpeedBased();
        float speedx = Mathf.Abs(rb.velocity.x);
        m_animator.speed = speedx / 2.0f;
    }

}
