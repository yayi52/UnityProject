using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bulletcreate4 : MonoBehaviour
{
    [SerializeField] private GameObject bulletprefab;
    [SerializeField] private Transform playertransform;
    public void createbullet()
    {
        Instantiate(bulletprefab, playertransform.position, Quaternion.identity);
    }

}
