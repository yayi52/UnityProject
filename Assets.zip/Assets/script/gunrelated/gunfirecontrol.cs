using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Timers;
using Unity.VisualScripting;

public class gunfirecontrol : MonoBehaviour
{
    [SerializeField] private selfdestroy destroy;
    
    private void Awake()
    {
        TimersManager.SetTimer(this , (float)0.2 , destroy.Destroy);
    } 
}
