using System.Collections;
using System.Collections.Generic;
using Timers;
using UnityEngine;

public class bullet : MonoBehaviour
{
    [SerializeField] private bulletcreate creator;
    private void launchbullet()
    {
        creator.createbullet();
    }

    private void Awake()
    {
        TimersManager.SetLoopableTimer(this, 1, launchbullet);
    }
}
