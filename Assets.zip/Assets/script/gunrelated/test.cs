using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using Timers;
using Unity.VisualScripting;

public class test : MonoBehaviour
{
    //[SerializeField] private bulletcreate create;
    //[SerializeField] private bulletcreate2 create2;
    //[SerializeField] private bulletcreate3 create3;
    //[SerializeField] private bulletcreate4 create4;
    //[SerializeField] private bulletcreate5 create5;
    [SerializeField] private shotgunfire gunfire;
    [SerializeField] private bulletcreateinf createinf;
    public int a = 1;
    private int temp;

    private bool _canshoot = true;
    public int ammohandgun;
    public int ammoshotgun;
    public int ammoshotguntotal;
    public int ammomachinegun;
    public int ammomachineguntotal;
    private void canshoot() 
    {
        _canshoot = true;
    }
    private void Awake()
    {
        ammohandgun = 15;
        ammoshotgun = 5;
        ammoshotguntotal = 20;
        ammomachinegun = 50;
        ammomachineguntotal = 100;
    }
    private void FixedUpdate()
    {
        if (Keyboard.current.digit1Key.wasPressedThisFrame)
        {
            print("1");
            a = 1;
        }
        if (Keyboard.current.digit2Key.wasPressedThisFrame)
        {
            print("2");
            a = 2;
        }
        if (Keyboard.current.digit3Key.wasPressedThisFrame)
        {
            print("3");
            a = 3;
        }
        if(Keyboard.current.rKey.wasPressedThisFrame)
        {
            if (a == 1) ammohandgun = 15;
            else if(a == 2)
            {
                temp = 5 - ammoshotgun;
                if(ammoshotguntotal >= temp)
                {
                    ammoshotgun = 5;
                    ammoshotguntotal -= temp;
                }
                else if (ammoshotguntotal < temp && ammoshotguntotal != 0)
                {
                    ammoshotgun += ammoshotguntotal;
                    ammoshotguntotal = 0;
                }
                else if (ammoshotguntotal == 0) return;
            }
            else if(a == 3)
            {
                temp = 50 - ammomachinegun;
                if(ammomachineguntotal >= temp)
                {
                    ammomachinegun = 50;
                    ammomachineguntotal -= temp;
                }
                else if(ammomachineguntotal < temp && ammomachineguntotal != 0)
                {
                    ammomachinegun += ammomachineguntotal;
                    ammomachineguntotal = 0;
                }
                else if(ammomachineguntotal == 0) return;
            }
        }
    }

    public void shot(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            switch (a)
            {
                case 1:
                    if (ammohandgun > 0)
                    {
                        if(!_canshoot) return;
                        createinf.createbullet();
                        ammohandgun--;
                        _canshoot = false;
                        TimersManager.SetTimer(this , 1, canshoot);

                        break;
                    }
                    else break;
                case 2:
                    if (ammoshotgun > 0)
                    {
                        if(!_canshoot) return;
                        gunfire.gunfire();
                        //create.createbullet();
                        //create2.createbullet();
                        //create3.createbullet();
                        //create4.createbullet();
                        //create5.createbullet();
                        ammoshotgun--;
                        _canshoot = false;
                        TimersManager.SetTimer(this , 2 , canshoot);
                        
                        break;
                    }
                    else break;
                case 3:
                    if (ammomachinegun > 0)
                    {
                        createinf.createbullet();
                        ammomachinegun--;
                        break;
                    }
                    else break;
                default:
                    break;
            }
        }
    }
    public int HandGun()
    {
        return ammohandgun;
    }
    public int ShotGun()
    {
        return ammoshotgun;
    }
    public int ShotGunTotal()
    {
        return ammoshotguntotal;
    }
    public int MachineGun()
    {
        return ammomachinegun;
    }
    public int MachineGunTotal()
    {
        return ammomachineguntotal;
    }
    public void SetHandGun(int _hand)
    {
        ammohandgun = _hand;
    }
    public void SetShotGun(int _shot)
    {
        ammoshotgun = _shot;
    }
    public void SetShotGunTotal(int _shotTotal)
    {
        ammoshotguntotal = _shotTotal;
    }
    public void SetMachineGun(int _machine)
    {
        ammomachinegun = _machine;
    }
    public void SetMachineGunTotal(int _machineTotal)
    {
        ammomachineguntotal = _machineTotal;
    }
}
