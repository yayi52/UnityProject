using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.InputSystem;

public class bulletmoveinf : MonoBehaviour
{
    private Vector2 mouse = new Vector2(0,0);
    private Vector2 mouse2 ;
    private Vector2 direction;
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed;
    [SerializeField] private selfdestroy selfdestroy;
    private void Awake()
    {
        mouse = Input.mousePosition;
        mouse2 = Camera.main.ScreenToWorldPoint(mouse);
        direction = mouse2 - (Vector2)transform.position;
        print(direction);
    }
    public void FixedUpdate()
    {
        var positionNow = (Vector2)transform.position;
        var positionafter = positionNow + direction;

        if (positionNow == positionafter) return;
        if (Input.GetMouseButtonUp(0)) return;

        rb.velocity = direction.normalized * speed;
        //transform.Translate((direction-(Vector2)transform.position).normalized * speed * Time.deltaTime);
        //rb.DOMove(positionafter, speed).SetSpeedBased();
        if(positionNow.x>500 || positionNow.x<=-100 || positionNow.y>=50 || positionNow.y<=-50)
        {
            selfdestroy.Destroy();
        }
    }

}
