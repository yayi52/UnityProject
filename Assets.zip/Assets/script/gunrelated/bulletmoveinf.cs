using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class bulletmoveinf : MonoBehaviour
{
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed;
    public void FixedUpdate()
    {
        var direction = new Vector2((float)5, 0);
        var positionNow = (Vector2)transform.position;
        var positionafter = positionNow + direction;

        if (positionNow == positionafter) return;
        if (Input.GetMouseButtonUp(0)) return;

        rb.DOMove(positionafter, speed).SetSpeedBased();
    }

}
