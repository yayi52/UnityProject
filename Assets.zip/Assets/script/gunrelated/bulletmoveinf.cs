using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.InputSystem;

public class bulletmoveinf : MonoBehaviour
{
    private Vector2 mouse = new Vector2(0,0);
    private Vector2 direction;
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed;
    [SerializeField] private selfdestroy selfdestroy;
    public void FixedUpdate()
    {
        if(mouse == new Vector2(0,0)) mouse = Input.mousePosition;//子彈有點不穩 會飄
        direction = Camera.main.ScreenToWorldPoint(mouse);
        print(direction);
        var positionNow = (Vector2)transform.position;
        var positionafter = positionNow + direction;

        if (positionNow == positionafter) return;
        if (Input.GetMouseButtonUp(0)) return;

        rb.DOMove(positionafter, speed).SetSpeedBased();
        if(positionNow.x>=100 || positionNow.x<=-100)
        {
            selfdestroy.Destroy();
        }
    }

}
