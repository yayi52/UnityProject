using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shotgunfire : MonoBehaviour
{
    private Vector2 mouse = new Vector2(0,0);
    private Vector2 mouse2 ;
    private Vector2 directionx;
    [SerializeField] private GameObject gunfireprefab;
    [SerializeField] private GameObject gunfireprefab1;
    [SerializeField] private Transform playertransform;
    public void gunfire()
    {
        mouse = Input.mousePosition;
        mouse2 = Camera.main.ScreenToWorldPoint(mouse);
        directionx = mouse2 - (Vector2)transform.position;
        var direction = new Vector2((float)4, 0);
        var position = (Vector2)playertransform.position;
        if(directionx.x > 0)Instantiate(gunfireprefab, position + direction, Quaternion.identity);
        if(directionx.x < 0)Instantiate(gunfireprefab1, position - direction, Quaternion.identity);
    }
}
