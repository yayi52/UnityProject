using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shotgunfire : MonoBehaviour
{
    [SerializeField] private GameObject gunfireprefab;
    [SerializeField] private Transform playertransform;
    public void gunfire()
    {
        var direction = new Vector2((float)3, 0);
        var position = (Vector2)playertransform.position;
        Instantiate(gunfireprefab, position + direction, Quaternion.identity);
    }
}
