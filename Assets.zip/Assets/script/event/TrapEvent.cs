using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Timers;
using UnityEngine.Events;

public class TrapEvent : MonoBehaviour
{
    private Camera cam;
    [SerializeField] private float y;
    [SerializeField] private GameObject trapPrefab;
    private float screenHalfWidth;
    [SerializeField] float waittime;
    // Start is called before the first frame update
    void Start()
    {
        cam =Camera.main;
        Vector2 projectpoint = cam.ScreenToWorldPoint(new Vector3(0, 0, 10));
        screenHalfWidth = Mathf.Abs(projectpoint.x - cam.transform.position.x);
        Trap();
    }

    // Update is called once per frame
    private void Trap()
    {        
        float point =2 * Random.value * screenHalfWidth+cam.transform.position.x-screenHalfWidth;
        Instantiate(trapPrefab, new Vector2(point,y), Quaternion.identity);
        TimersManager.SetTimer(this,waittime,Trap);
    }
}
