using System.Collections;
using System.Collections.Generic;
using System.Threading;
using Timers;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;

public class BloodRainEvent : MonoBehaviour
{
    [SerializeField] private UnityEvent BloodRain, end;
    [SerializeField] private GameObject bloodPrefab;
    private Camera cam;
    private float screenHalfWidth, sec;
    [SerializeField] float waittime;
    // Start is called before the first frame update
    void Start()
    {
        //取得攝影機的位置，以計算隨機掉落的範圍
        cam =Camera.main;
        Vector2 projectpoint = cam.ScreenToWorldPoint(new Vector3(0, 0, 10));
        screenHalfWidth = Mathf.Abs(projectpoint.x - cam.transform.position.x);
        BloodEventStart();
    }
    private void BloodEventStart()
    {
        sec = 0;
        //3秒延遲
        TimersManager.SetTimer(this,3.0f,Raining);
    }
    private void Raining()
    {   
        //開始下雨
        BloodRain.Invoke();  
        //隨機掉落
        float i = Random.value;
        float point =2 * i * screenHalfWidth+cam.transform.position.x-screenHalfWidth;
        sec += waittime;
        Instantiate(bloodPrefab, new Vector2(point,10), Quaternion.identity);
        TimersManager.SetTimer(this,waittime,Raining);
        if(sec >6.0f)//6秒後停止
        {
            BloodEventStart();
            end.Invoke();      
        }
    }
    void FixedUpdate()
    {
        if(bloodPrefab.transform.position.y <-100)
        {
            Destroy(gameObject);
        }
    }
}