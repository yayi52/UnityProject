using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using Timers;

public class test : MonoBehaviour
{
    [SerializeField] private bulletcreate create;
    [SerializeField] private bulletcreate2 create2;
    [SerializeField] private bulletcreate3 create3;
    [SerializeField] private bulletcreate4 create4;
    [SerializeField] private bulletcreate5 create5;
    [SerializeField] private bulletcreateinf createinf;
    public int a = 1;
    private int temp;
    public int ammohandgun;
    public int ammoshotgun;
    public int ammoshotguntotal;
    /*public IEnumerator MethodWithDelay()
    {
        //some inital logic here

        yield return new WaitForSeconds(1); //delay here

        //rest of logic here
    }*/
    private void Awake()
    {
        ammohandgun = 15;
        ammoshotgun = 5;
        ammoshotguntotal = 20;
    }
    private void FixedUpdate()
    {
        if (Keyboard.current.digit1Key.wasPressedThisFrame)
        {
            print("1");
            a = 1;
        }
        if (Keyboard.current.digit2Key.wasPressedThisFrame)
        {
            print("2");
            a = 2;
        }
        if (Keyboard.current.digit3Key.wasPressedThisFrame)
        {
            print("3");
            a = 3;
        }
        if(Keyboard.current.rKey.wasPressedThisFrame)
        {
            if (a == 1) ammohandgun = 15;
            else if(a == 2)
            {
                temp = 5 - ammoshotgun;
                if(ammoshotguntotal >= temp)
                {
                    ammoshotgun = 5;
                    ammoshotguntotal -= temp;
                }
                else if (ammoshotguntotal < temp && ammoshotguntotal != 0)
                {
                    ammoshotgun += ammoshotguntotal;
                    ammoshotguntotal = 0;
                }
                else if (ammoshotguntotal == 0) return;
            }
            else if(a == 3)
            { }
        }
    }

    public void shot(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            switch (a)
            {
                case 1:
                    if (ammohandgun > 0)
                    {
                        createinf.createbullet();
                        ammohandgun--;
                        break;
                    }
                    else break;
                case 2:
                    if (ammoshotgun > 0)
                    {
                        create.createbullet();
                        create2.createbullet();
                        create3.createbullet();
                        create4.createbullet();
                        create5.createbullet();
                        ammoshotgun--;
                        break;
                    }
                    else break;
                case 3:
                    break;
                default:
                    break;
            }
            //MethodWithDelay();
            //�Pı�ݭnpause time�n�A�g
        }
    }
 

}
