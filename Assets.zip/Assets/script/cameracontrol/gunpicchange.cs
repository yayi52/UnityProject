using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class gunpicchange : MonoBehaviour
{
    [SerializeField] private GameObject image;
    [SerializeField] private Texture2D handgun;
    [SerializeField] private Texture2D shotgun;
    
    private void FixedUpdate()
    {
        if(Input.GetKeyDown(KeyCode.Alpha1))
        {
            if(image.GetComponent<RawImage>().texture == handgun) return;
            image.GetComponent<RawImage>().texture = handgun;
        }
        else if(Input.GetKeyDown(KeyCode.Alpha2))
        {
            if (image.GetComponent<RawImage>().texture == shotgun) return;
            image.GetComponent<RawImage>().texture = shotgun;
        }
        else if(Input.GetKeyDown(KeyCode.Alpha3))
        {

        }
    }
}
