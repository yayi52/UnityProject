using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;

public class gunpicchange : MonoBehaviour
{
    [SerializeField] private GameObject image;
    [SerializeField] private Texture2D handgun;
    [SerializeField] private Texture2D shotgun;
    
    private void FixedUpdate()
    {
        if(Keyboard.current.digit1Key.wasPressedThisFrame)
        {
            if(image.GetComponent<RawImage>().texture == handgun) return;
            image.GetComponent<RawImage>().texture = handgun;
        }
        else if(Keyboard.current.digit2Key.wasPressedThisFrame)
        {
            if (image.GetComponent<RawImage>().texture == shotgun) return;
            image.GetComponent<RawImage>().texture = shotgun;
        }
        else if(Keyboard.current.digit3Key.wasPressedThisFrame)
        {

        }
    }
}
