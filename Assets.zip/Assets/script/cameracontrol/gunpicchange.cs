using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class gunpicchange : MonoBehaviour
{
    [SerializeField] private GameObject image;
    [SerializeField] private Texture2D handgun;
    [SerializeField] private Texture2D shotgun;
    [SerializeField] private Texture2D machinegun;
    
    private void FixedUpdate()
    {
        if(Input.GetKey(KeyCode.Alpha1))
        {
            if(image.GetComponent<RawImage>().texture == handgun) return;
            image.GetComponent<RawImage>().texture = handgun;
        }
        else if(Input.GetKey(KeyCode.Alpha2))
        {
            if(SceneManager.GetActiveScene().buildIndex<2) return;
            if (image.GetComponent<RawImage>().texture == shotgun) return;
            image.GetComponent<RawImage>().texture = shotgun;
        }
        else if(Input.GetKey(KeyCode.Alpha3))
        {
            if(SceneManager.GetActiveScene().buildIndex<3) return;
            if (image.GetComponent<RawImage>().texture == machinegun) return;
            image.GetComponent<RawImage>().texture = machinegun;
        }
    }
}
