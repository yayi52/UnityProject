using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class bulletnumUI : MonoBehaviour
{
    [SerializeField] private Text number;
    [SerializeField] private test test;
    // Start is called before the first frame update

    private void FixedUpdate()
    {
        if (test.a == 1) number.text = test.ammohandgun.ToString() + "/��";
        else if (test.a == 2) number.text = test.ammoshotgun.ToString() + "/" + test.ammoshotguntotal.ToString();
        else if (test.a == 3)
        { }
    }

}
