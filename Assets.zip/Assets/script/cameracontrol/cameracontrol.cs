using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.Build.Content;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class CameraControl : MonoBehaviour
{
    private Camera cam;
    public Transform player;
    private BoxCollider2D CameraBounding;
    private float screenHalfWidth, screenHalfHeight, i=0f;
    private BoxCollider2D CameraBounding3;
    [SerializeField] private UnityEvent FinalPlot;
    void Start()
    {
        StaticValue.Finalboss = false;
        cam = Camera.main;
        cam.transform.position = new Vector3(player.position.x, player.position.y, -10f);

        var boundObject = GameObject.Find("CameraBounding");
        var boundObject3 = GameObject.Find("CameraBounding3");
        if (boundObject)
        {
            CameraBounding = boundObject.GetComponent<BoxCollider2D>();
        }
        if (boundObject3)
        {
            CameraBounding3 = boundObject3.GetComponent<BoxCollider2D>();
        }
        Vector2 projectpoint = cam.ScreenToWorldPoint(new Vector3(0, 0, 10));
        screenHalfWidth = Mathf.Abs(projectpoint.x - cam.transform.position.x);
        screenHalfHeight = Mathf.Abs(projectpoint.y - cam.transform.position.y);
    }
    void Update()
    {
        var newCamPosX = player.position.x;
        var newCamPosY = player.position.y;
        var offset = CameraBounding.offset;
        var size = CameraBounding.size;

        if (player.position.x < offset.x - size.x / 2 + screenHalfWidth)
        {
            newCamPosX = offset.x - size.x / 2 + screenHalfWidth;
        }
        if (player.position.x > offset.x + size.x / 2 - screenHalfWidth)
        {   
            newCamPosX = offset.x + size.x / 2 - screenHalfWidth;
        }
        if (player.position.y < offset.y - size.y / 2 + screenHalfHeight)
        {
            newCamPosY = offset.y - size.y / 2 + screenHalfHeight;
        }
        if (player.position.y > offset.y + size.y / 2 - screenHalfHeight)
        {
            newCamPosY = offset.y + size.y / 2 - screenHalfHeight;
        }

        if(SceneManager.GetActiveScene().buildIndex == 3)
        {
            if(player.position.x > CameraBounding3.offset.x - CameraBounding3.size.x / 2 + screenHalfWidth )
            {
                i+=1;
                if(i<=1)FinalPlot.Invoke();
                StaticValue.Finalboss = true;
            }
            if(StaticValue.Finalboss)
            {
                if(player.position.x < CameraBounding3.offset.x - CameraBounding3.size.x / 2 + screenHalfWidth)
                {
                    newCamPosX = CameraBounding3.offset.x - CameraBounding3.size.x / 2 + screenHalfWidth;
                }
                if(player.position.x > CameraBounding3.offset.x + CameraBounding3.size.x / 2 - screenHalfWidth)
                {
                    newCamPosX = CameraBounding3.offset.x + CameraBounding3.size.x / 2 - screenHalfWidth;
                }
                if(player.position.y < CameraBounding3.offset.y - CameraBounding3.size.y / 2 + screenHalfHeight)
                {
                    newCamPosY = CameraBounding3.offset.y - CameraBounding3.size.y / 2 + screenHalfHeight;
                }
                if(player.position.y > CameraBounding3.offset.y + CameraBounding3.size.y / 2 - screenHalfHeight)
                {
                    newCamPosY = CameraBounding3.offset.y + CameraBounding3.size.y / 2 - screenHalfHeight;
                }
            }
        }
        cam.transform.position = new Vector3(newCamPosX, newCamPosY, cam.transform.position.z);
    }
}