using System.Collections;
using System.Collections.Generic;
using UnityEditor.Build.Content;
using UnityEngine;

public class CameraControl : MonoBehaviour
{
    private Camera cam;
    public Transform player;
    private BoxCollider2D CameraBounding;
    private float screenHalfWidth, screenHalfHeight;
    void Start()
    {
        cam = Camera.main;
        cam.transform.position = new Vector3(player.position.x, player.position.y, -10f);

        var boundObject = GameObject.Find("CameraBounding");
        if (boundObject)
        {
            CameraBounding = boundObject.GetComponent<BoxCollider2D>();
        }
        Vector2 projectpoint = cam.ScreenToWorldPoint(new Vector3(0, 0, 10));
        screenHalfWidth = Mathf.Abs(projectpoint.x - cam.transform.position.x);
        screenHalfHeight = Mathf.Abs(projectpoint.y - cam.transform.position.y);
    }
    void Update()
    {
        var newCamPosX = player.position.x;
        var newCamPosY = player.position.y;
        var offset = CameraBounding.offset;
        var size = CameraBounding.size;

        if (player.position.x < offset.x - size.x / 2 + screenHalfWidth)
        {
            newCamPosX = offset.x - size.x / 2 + screenHalfWidth;
        }
        if (player.position.x > offset.x + size.x / 2 - screenHalfWidth)
        {
            newCamPosX = offset.x + size.x / 2 - screenHalfWidth;
        }
        if (player.position.y < offset.y - size.y / 2 + screenHalfHeight)
        {
            newCamPosY = offset.y - size.y / 2 + screenHalfHeight;
        }
        if (player.position.y > offset.y + size.y / 2 - screenHalfHeight)
        {
            newCamPosY = offset.y + size.y / 2 - screenHalfHeight;
        }

        cam.transform.position = new Vector3(newCamPosX, newCamPosY, cam.transform.position.z);
    }
}