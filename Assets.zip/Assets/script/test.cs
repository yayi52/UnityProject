using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using Timers;

public class test : MonoBehaviour
{
    [SerializeField] private bulletcreate create;
    [SerializeField] private bulletcreate2 create2;
    [SerializeField] private bulletcreate3 create3;
    [SerializeField] private bulletcreate4 create4;
    [SerializeField] private bulletcreate5 create5;
    [SerializeField] private bulletcreateinf createinf;
    int a = 1;
    /*public IEnumerator MethodWithDelay()
    {
        //some inital logic here

        yield return new WaitForSeconds(1); //delay here

        //rest of logic here
    }*/

    private void FixedUpdate()
    {
        if (Keyboard.current.digit1Key.wasPressedThisFrame)
        {
            print("1");
            a = 1;
        }
        if (Keyboard.current.digit2Key.wasPressedThisFrame)
        {
            print("2");
            a = 2;
        }
        if (Keyboard.current.digit3Key.wasPressedThisFrame)
        {
            print("3");
            a = 3;
        }
    }

    public void shot(InputAction.CallbackContext context)
    {
        if (context.performed)
        {
            switch (a)
            {
                case 1:
                    createinf.createbullet();
                    break;
                case 2:
                    create.createbullet();
                    create2.createbullet();
                    create3.createbullet();
                    create4.createbullet();
                    create5.createbullet();
                    break;
                case 3:
                    break;
                default:
                    break;
            }
            //MethodWithDelay();
            //�Pı�ݭnpause time�n�A�g
        }
    }
 

}
