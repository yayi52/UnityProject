using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using Timers;

public class test : MonoBehaviour
{
    [SerializeField] private bulletcreate create;
    [SerializeField] private bulletmove move;
    private float mouse;
    public void shot(InputAction.CallbackContext context)
    {
        mouse = context.ReadValue<float>();
    }
    public void FixedUpdate()
    {
        if(Input.GetMouseButtonDown(0))
        {
            create.createbullet();
            move.FixedUpdate();
            //�Pı�ݭnpause time�n�A�g
        }
    }

}
