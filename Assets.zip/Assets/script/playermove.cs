using UnityEngine;
using UnityEngine.InputSystem;
using DG.Tweening;
public class playermove : MonoBehaviour
{
    [SerializeField] private Rigidbody2D rb;
    [SerializeField] private float speed;
    private Vector2 _inputdirection;

    public void Move(InputAction.CallbackContext context)
    {
        _inputdirection = context.ReadValue<Vector2>();
    }

    private void FixedUpdate()
    {
        var positionNow = (Vector2)transform.position;
        var positionafter = positionNow + _inputdirection;

        if (positionNow == positionafter) return;

        rb.DOMove(positionafter , speed).SetSpeedBased();
    }

}
