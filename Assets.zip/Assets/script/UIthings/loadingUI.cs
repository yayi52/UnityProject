using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class loadingUI : MonoBehaviour
{
    [SerializeField] private Text number1;
    [SerializeField] private Text number2;
    [SerializeField] private Text number3;
    //public int file;
    // Start is called before the first frame update
    // Update is called once per frame
    void Start()
    {
        PlayerData data = SaveSystem.LoadPlayer(1);  
        number1.text = "關卡 : " + data.Level.ToString() + Environment.NewLine
                       + "當前血量 : " + data.health.ToString() + "0" + Environment.NewLine
                       + "剩餘時間 : " + data.remaingTime.ToString() + "秒";
        PlayerData data2 = SaveSystem.LoadPlayer(2);     
        number2.text = "關卡 : " + data2.Level.ToString() + Environment.NewLine
                       + "當前血量 : " + data2.health.ToString() + "0" + Environment.NewLine
                       + "剩餘時間 : " + data2.remaingTime.ToString() + "秒";
        PlayerData data3 = SaveSystem.LoadPlayer(3);
        number3.text = "關卡 : " + data3.Level.ToString() + Environment.NewLine
                       + "當前血量 : " + data3.health.ToString() + "0" + Environment.NewLine
                       + "剩餘時間 : " + data3.remaingTime.ToString() + "秒";
    }
}
