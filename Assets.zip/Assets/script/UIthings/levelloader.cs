using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class levelloader : MonoBehaviour
{
    public Animator transition;
    public float WaitTime = 2.0f;
   
    public void LoadNextLevel(int level)
    {
        StartCoroutine(LoadLevel(level));
    }
    IEnumerator LoadLevel(int level)
    {
        transition.SetTrigger("Start");        
        yield return new WaitForSecondsRealtime(WaitTime);
        SceneManager.LoadScene(level);
    }

}
