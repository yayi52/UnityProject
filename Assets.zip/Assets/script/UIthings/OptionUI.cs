using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class OptionUI : MonoBehaviour
{
    [SerializeField] private Text text1;
    [SerializeField] private Text text2;
    // Start is called before the first frame update
    void Start()
    {
        text1.text = "·按下鍵盤A鍵與D鍵來左右移動角色" + Environment.NewLine + Environment.NewLine
                  + "·按下space鍵使角色跳躍" + Environment.NewLine + Environment.NewLine
                  + "·按下數字鍵1,2,3切換手槍,散彈槍以及機槍" + Environment.NewLine + Environment.NewLine
                  + "·手槍："+ Environment.NewLine + "  射程：遠  射速：中  傷害：一般  彈藥：無限" 
                  + Environment.NewLine +"·散彈槍："+ Environment.NewLine + "  射程：近  射速：慢  傷害：高  彈藥：有限"
                  + Environment.NewLine + "·機槍："+ Environment.NewLine + "  射程：遠  射速：快  傷害：一般  彈藥：有限";
        text2.text = "·利用跳躍和移動躲避敵人攻擊" + Environment.NewLine + Environment.NewLine
                   + "·利用槍將敵人擊斃" + Environment.NewLine + Environment.NewLine
                   + "·場景中偶爾會出現陷阱" + Environment.NewLine
                   + "須即時跳離開否則將被束縛數秒" + Environment.NewLine + Environment.NewLine
                   + "·場景中有時會發生血雨事件 天上會降下血紅色的雨" + Environment.NewLine
                   + "需移動來躲避否則會受傷";              
    }
}

