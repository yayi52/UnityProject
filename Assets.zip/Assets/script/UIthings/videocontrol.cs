using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Video;
using Timers;
using UnityEngine.Events;

public class videocontrol : MonoBehaviour
{
    // Start is called before the first frame update
    [SerializeField]private UnityEvent video;
    [SerializeField]private UnityEvent videoclose;
    public VideoPlayer video1;
    public VideoPlayer video2;
    public VideoPlayer video3;
    public AudioSource BG;
    private int count = 0;
    private Vector3 previousMousePosition;
    void counting()
    {
        count++;
        TimersManager.SetTimer(this , 1.0f , counting );
    }
    void Awake()
    {
        counting();
    }
    void Start()
    {
        previousMousePosition =Input.mousePosition;
    }
    // Update is called once per frame
    void Update()
    {
        Vector3 currentMousePosition = Input.mousePosition;
        if(Input.anyKeyDown || currentMousePosition != previousMousePosition)
        {
            count = 0;
            video1.Stop();
            video2.Stop();
            video3.Stop();
            BG.mute = false;
            previousMousePosition = currentMousePosition;
            videoclose.Invoke();
        }
        if(count >= 10)
        {
            BG.mute = true;
            if(video1.isPlaying || video2.isPlaying || video3.isPlaying) return;
            if(Random.value < 0.3f) 
            {
                video1.Play();
                video2.Stop();
                video3.Stop();
            }
            else if(Random.value > 0.3f && Random.value < 0.6f) 
            {
                video1.Stop();
                video2.Play();
                video3.Stop();
            }
            else 
            {
                video3.Play();
                video2.Stop();
                video1.Stop();
            }
            video.Invoke();
        }
    }
}
