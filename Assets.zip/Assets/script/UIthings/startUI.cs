using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartUI : MonoBehaviour
{
    [SerializeField]private levelloader _levelloader;
    public void StartButton(int level)
    {
        StaticValue.Level = 0;
        _levelloader.LoadNextLevel(level);
    }
    public void LoadButtion(int level)
    {
        StaticValue.Level = level;
        _levelloader.LoadNextLevel(level);
    }
    public void Quitgame()
    {
        Application.Quit();
    }
    
}