using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartUI : MonoBehaviour
{
    public void StartButton(int level)
    {
        SceneManager.LoadScene(level);
    }
    public void Quitgame()
    {
        Application.Quit();
    }
    
}