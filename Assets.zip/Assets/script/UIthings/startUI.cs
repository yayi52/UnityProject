using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartUI : MonoBehaviour
{
    [SerializeField]private levelloader _levelloader;
    void Start()
    {
        StaticValue.Level = 0;
    }
    public void StartButton()
    {
        StaticValue.Level = 1;
        StaticValue.deathcount = 0;
        _levelloader.LoadNextLevel(StaticValue.Level);
    }
    public void LoadButtion(int file)
    {
        StaticValue.load = true;
        StaticValue.file = file;
        PlayerData data = SaveSystem.LoadPlayer(StaticValue.file);
        _levelloader.LoadNextLevel(data.Level);
    }
    public void Difficulty(bool hard)
    {
        StaticValue.hard = hard;
    }
    public void Quitgame()
    {
        Application.Quit();
    }
    
}