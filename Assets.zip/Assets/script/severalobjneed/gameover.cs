using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{
   [SerializeField] private levelloader levelloader;
   public void Restart()
   {
      SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
   }
   public void next(int level)
   {
      StaticValue.Level = level;
      levelloader.LoadNextLevel(level);
   }
}
