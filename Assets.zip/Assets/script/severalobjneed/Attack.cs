using System.Collections;
using System.Collections.Generic;
using Timers;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;

public class Attack : MonoBehaviour
{
    private bool _canAttack = true;
    private Collider2D col;
    [SerializeField]private string targetTag="";
    [SerializeField]private UnityEvent attack;
    [SerializeField]private int power;
    [SerializeField]private enemymove enemymove;
    [SerializeField]private selfdestroy selfdestroy;
    [SerializeField]private BoxCollider2D Trap;
    private Animator m_animator;
    
    //test function
   /* void Start()
    {
        col.GetComponent<Damageable>();
    }
    void Update()
    {
        if(!_canAttack)return;
        var damageable = col.GetComponent<Damageable>();
        TimersManager.SetTimer(this,1,canAttack);
        _canAttack = false;
    }*/
    void Start()
    {
        TimersManager.SetTimer(this, 1,DelayTrap);
        m_animator=GetComponent<Animator>();
        if(this.CompareTag("Trap")) TimersManager.SetTimer(this,2,Destroy);
    }
    void Destroy()
    {
        selfdestroy.Destroy();
    }

    private void canAttack()
    {
        _canAttack = true;
        if(targetTag == "Player")
        {
            enemymove.enabled = true;
            m_animator.SetBool("attack", false);
        }
    }
    private void DelayTrap()
    {
        Trap.enabled = true;
    }
   private void OnTriggerEnter2D(Collider2D col)
   {    
        if(!_canAttack)return;
        if(col.CompareTag(targetTag))
        {
            if(targetTag == "Player"&& this.CompareTag("Enemy"))
            {
                enemymove.enabled = false;
                m_animator.SetBool("attack", true);
            }
            var damageable = col.GetComponent<Damageable>();
            if(this.CompareTag("Healer")&& targetTag =="Enemy")
            {
                damageable.GetHealth(power);    
            }
            else if (this.CompareTag("Healer1")&&targetTag == "Player")
            {
                damageable.GetHealth(power);
            }
            else if(this.CompareTag("Trap")&&targetTag == "Player")
            {
                damageable.GetTrapped();
            }
            else
            {
                damageable.TakeDamage(power);
            }
            if(!this.CompareTag("shotgun"))
            {   
                    TimersManager.SetTimer(this,1,canAttack);
                    _canAttack = false;
            }
            attack.Invoke();
        }
   }
   private void OnTriggerStay2D(Collider2D col)
   {    
        if(!_canAttack)return;
        if(col.CompareTag(targetTag))
        {
            if(targetTag == "Player")
            {
                enemymove.enabled = false;
                m_animator.SetBool("attack", true);
            }
            var damageable = col.GetComponent<Damageable>();
            damageable.TakeDamage(power);
            _canAttack = false;
            TimersManager.SetTimer(this,1,canAttack);
            attack.Invoke(); 
        }
   }
}
