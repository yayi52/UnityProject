using System.Collections;
using System.Collections.Generic;
using Timers;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;

public class Attack : MonoBehaviour
{
    private bool _canAttack = true;
    private Collider2D col;
    [SerializeField]private string targetTag="";
    [SerializeField]private UnityEvent attack;
    [SerializeField]private int power;
    private Animator m_animator;
    //test function
   /* void Start()
    {
        col.GetComponent<Damageable>();
    }
    void Update()
    {
        if(!_canAttack)return;
        var damageable = col.GetComponent<Damageable>();
        TimersManager.SetTimer(this,1,canAttack);
        _canAttack = false;
    }*/
    void Start()
    {
        m_animator=GetComponent<Animator>();
    }

    private void canAttack()
    {
        _canAttack = true;
    }
   private void OnTriggerEnter2D(Collider2D col)
   {    
        if(!_canAttack)return;
        if(col.CompareTag(targetTag))
        {
            //m_animator.SetBool("attack", true);//要改
            var damageable = col.GetComponent<Damageable>();
            damageable.TakeDamage(power);
            TimersManager.SetTimer(this,1,canAttack);
            _canAttack = false;
            attack.Invoke();
        }
   }
   private void OnTriggerStay2D(Collider2D col)
   {    
        if(!_canAttack)return;
        if(col.CompareTag(targetTag))
        {
            //m_animator.SetBool("attack", true);//要改
            var damageable = col.GetComponent<Damageable>();
            damageable.TakeDamage(power);
            TimersManager.SetTimer(this,1,canAttack);
            _canAttack = false;
            attack.Invoke(); 
        }
   }
}
