using System.Collections;
using System.Collections.Generic;
using Timers;
using Unity.VisualScripting;
using UnityEngine;

public class Attack : MonoBehaviour
{
    private bool _canAttack = true;
    private Collider2D col;
    //test function
   /* void Start()
    {
        col.GetComponent<Damageable>();
    }
    void Update()
    {
        if(!_canAttack)return;
        var damageable = col.GetComponent<Damageable>();
        TimersManager.SetTimer(this,1,canAttack);
        _canAttack = false;
    }*/
    
    private void canAttack()
    {
        _canAttack = true;
    }
   private void OnTriggerEnter2D(Collider2D col)
   {    
        if(!_canAttack)return;
        if(col.CompareTag("Player"))
        {
            var damageable = col.GetComponent<Damageable>();
            damageable.TakeDamage(1);
            TimersManager.SetTimer(this,1,canAttack);
            _canAttack = false;
        }
   }
   private void OnTriggerStay2D(Collider2D col)
   {    
        if(!_canAttack)return;
        if(col.CompareTag("Player"))
        {
            var damageable = col.GetComponent<Damageable>();
            damageable.TakeDamage(1);
            TimersManager.SetTimer(this,1,canAttack);
            _canAttack = false;
        }
   }
}
