using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using Timers;
using UnityEngine.InputSystem;

public class Damageable : MonoBehaviour
{
    [SerializeField]private Health health;
    [SerializeField]private SpriteRenderer spriteRenderer;
    [SerializeField]private playermove playermove;
    [SerializeField]private JumpControl jumpControl;
    [SerializeField]private test test;
    [SerializeField]private Rigidbody2D rb;
    public Animator transition;
    private void Awake()
    {
        transition = GetComponent<Animator>();
    }
    private void Trap()
    {
        transition.Play("playertrap");
        playermove.enabled = false;
        jumpControl.enabled = false;
        test.enabled = false;
        
        rb.velocity = new Vector2(0,0);
    }
    private void Resume()
    {
        playermove.enabled = true;
        jumpControl.enabled = true;
        test.enabled = true;
        transition.SetBool("Trap" , false);
    }
    public void TakeDamage(int damage)
    {
        health.DecreaseHealth(damage);
        spriteRenderer.DOColor(Color.red,0.2f).SetLoops(2,LoopType.Yoyo).ChangeStartValue(Color.white);
    }
    public void GetHealth(int damage)
    {
        health.IncreaseHealth(damage);
        spriteRenderer.DOColor(Color.green,0.2f).SetLoops(2,LoopType.Yoyo).ChangeStartValue(Color.white);
    }
    public void GetTrapped()
    {
        Trap();
        TimersManager.SetTimer(this, 2 , Resume);
    }
}
