using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class TimeCount : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI TimerText;
    [SerializeField] private float RemaingTime;
    [SerializeField] private UnityEvent CountDown, Pass;

    void Update()
    {
        if(RemaingTime > 0)
        {
            RemaingTime -= Time.deltaTime;
        }
        else if(RemaingTime < 0)
        {
            RemaingTime = 0;
            CountDown.Invoke();
        }
        if(StaticValue.ZombieHistory==StaticValue.ZombieTotal && StaticValue.ZombieNumber==0)
        {
            switch(SceneManager.GetActiveScene().buildIndex)
            {
                case 1:
                    Pass.Invoke();
                    break;
                case 2:
                    if(StaticValue.Pass)
                    {
                        Pass.Invoke();
                    }
                    break;
                case 3:
                    if(StaticValue.Pass)
                    {
                        Pass.Invoke();
                    }
                    break;
                default: break;
            }
        }
        else StaticValue.Pass= false;
        int minutes = Mathf.FloorToInt(RemaingTime /60);
        int seconds = Mathf.FloorToInt(RemaingTime %60);
        TimerText.text = string.Format("{0:00}:{1:00}",minutes,seconds);
    }
    public float Value
    {
        get {return RemaingTime;}
    }
    public void SetRemaningTime(float _RemaingTime)
    {
        RemaingTime = _RemaingTime;
    }
}
