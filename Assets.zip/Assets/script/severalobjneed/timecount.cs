using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.Events;
using UnityEngine.SceneManagement;

public class TimeCount : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI TimerText,Score;
    [SerializeField] private float RemaingTime;
    [SerializeField] private UnityEvent CountDown, Pass, Finish;
    [SerializeField] private Health health;
    private int survival = 0;
    void Start()
    {
        if(StaticValue.hard)RemaingTime -=30;
    }
    void Update()
    {
        if(RemaingTime > 0)
        {
            RemaingTime -= Time.deltaTime;
            if(StaticValue.Finalboss)_survival();
        }
        else if(RemaingTime < 0)
        {
            RemaingTime = 0;
            if(!StaticValue.Finalboss)CountDown.Invoke();
            else
            {
                Finish.Invoke();
                Score.text = string.Format("Zombie Killed:" + StaticValue.ZombieKilled
                                                +"\nScore:" + StaticValue.ZombieKilled*100
                                                +"\nRemaining Health:" + health.Value);
            }
        }
        if(StaticValue.ZombieHistory==StaticValue.ZombieTotal && StaticValue.ZombieNumber==0)
        {
            switch(SceneManager.GetActiveScene().buildIndex)
            {
                case 1:
                    Pass.Invoke();
                    Score.text = string.Format("Zombie Killed:" + StaticValue.ZombieKilled
                                                +"\nScore:" + StaticValue.ZombieKilled*100
                                                +"\nRemaining Health:" + health.Value);
                    break;
                case 2:
                    if(StaticValue.Pass)
                    {
                        Pass.Invoke();
                        Score.text = string.Format("Zombie Killed:" + StaticValue.ZombieKilled
                                                +"\nScore:" + StaticValue.ZombieKilled*100
                                                +"\nRemaining Health:" + health.Value);
                    }
                    break;
                case 3: break;
                default: break;
            }
        }
        else StaticValue.Pass= false;
        int minutes = Mathf.FloorToInt(RemaingTime /60);
        int seconds = Mathf.FloorToInt(RemaingTime %60);
        if(!StaticValue.Finalboss)TimerText.text = string.Format("Zombie Remain:"+StaticValue.ZombieRemain+"\n{0:00}:{1:00}",minutes,seconds);
        if (StaticValue.Finalboss)
        {
            TimerText.text = string.Format("Survival Time:{0:00}:{1:00}",minutes,seconds);
        }
    }
    private void _survival()
    {
        survival += 1;
        if (survival <=1)RemaingTime = 20;
    }
    public float Value
    {
        get {return RemaingTime;}
    }
    public void SetRemaningTime(float _RemaingTime)
    {
        RemaingTime = _RemaingTime;
    }
}
