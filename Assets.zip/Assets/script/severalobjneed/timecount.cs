using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.Events;

public class TimeCount : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI TimerText;
    [SerializeField] private float RemaingTime;
    [SerializeField] private UnityEvent CountDown, Pass;

    void Update()
    {
        if(RemaingTime > 0)
        {
            RemaingTime -= Time.deltaTime;
        }
        else if(RemaingTime < 0)
        {
            RemaingTime = 0;
            CountDown.Invoke();
        }
        if(StaticValue.ZombieHistory==20 && StaticValue.ZombieNumber==0)
        {
            Pass.Invoke();
        }
        int minutes = Mathf.FloorToInt(RemaingTime /60);
        int seconds = Mathf.FloorToInt(RemaingTime %60);
        TimerText.text = string.Format("{0:00}:{1:00}",minutes,seconds);
    }
    public float Value
    {
        get {return RemaingTime;}
    }
    public void SetRemaningTime(float _RemaingTime)
    {
        RemaingTime = _RemaingTime;
    }
}
