using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Timers;

public class selfdestroy : MonoBehaviour
{
    public void Destroy()
    {
        Destroy(gameObject);
    }
}
