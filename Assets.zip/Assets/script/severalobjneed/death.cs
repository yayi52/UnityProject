using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Timers;

public class Death : MonoBehaviour
{
    [SerializeField]private UnityEvent died;
    [SerializeField]private BoxCollider2D bc;
    [SerializeField]private enemymove enemymove;
    [SerializeField]private playermove playermove;
    [SerializeField]private JumpControl jumpControl;
    [SerializeField]private Rigidbody2D rb;
    [SerializeField]private selfdestroy destroy;
    public Animator transition;
    void Start()
    {
        transition = GetComponent<Animator>();
    }
    public void CheckDeath(int health)
    {
        if(health<=0)
        {
            bc.enabled = false;
            if(gameObject.CompareTag("Player"))
            {
                rb.gravityScale = 0;
                playermove.enabled = false;
                jumpControl.enabled = false;
                rb.velocity = new Vector2(0,0);
                transition.SetTrigger("Death");
                TimersManager.SetTimer(this , 1f , Die);
            }
            if(gameObject.CompareTag("Enemy"))
            {
                StaticValue.ZombieNumber--;
                enemymove.enabled = false;
                Destroy(rb);
                Destroy(bc);
                transition.SetTrigger("death");
                TimersManager.SetTimer(this , 2f , enemydestroy);
            }
        }
    }
    private void Die()
    {
        gameObject.SetActive(false);
        died.Invoke();
    }

    public void enemydestroy()
    {
        destroy.Destroy();
    }
}
