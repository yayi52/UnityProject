using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Timers;

public class Death : MonoBehaviour
{
    [SerializeField]private UnityEvent died;
    [SerializeField]private selfdestroy destroy;
    public Animator transition;
    void Start()
    {
        transition = GetComponent<Animator>();
    }
    public void CheckDeath(int health)
    {
        if(health<=0)
        {
            if(gameObject.CompareTag("Player"))
            {
                transition.SetTrigger("Death");
                TimersManager.SetTimer(this , 1f , Die);
            }
            if(gameObject.CompareTag("Enemy"))
            {
                StaticValue.ZombieNumber--;
                destroy.Destroy();
            }
        }
    }
    private void Die()
    {
        gameObject.SetActive(false);
        died.Invoke();
    }
}
