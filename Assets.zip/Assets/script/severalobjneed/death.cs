using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using Timers;

public class Death : MonoBehaviour
{
    [SerializeField]private UnityEvent died;
    public Animator transition;
    void Start()
    {
        transition = GetComponent<Animator>();
    }
    public void CheckDeath(int health)
    {
        if(health<=0)
        {
            transition.SetTrigger("Death");
            TimersManager.SetTimer(this , 1f , Die);
        }
    }
    private void Die()
    {
        gameObject.SetActive(false);
        died.Invoke();
    }
}
